import circle from './circle'
import curve from './curve'
import rect from './rect'
import text from './text'
import icon from './icon'
import arrow from './arrow'

export const pathList = [circle, curve, rect, text, icon, arrow]
