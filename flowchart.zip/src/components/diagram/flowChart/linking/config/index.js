export default {
  panelBorder: 0.05,

  LINE_STYLE: '#BBBBC8',
  LINE_BRIGHT_STYLE: '#578FFF',

  lineWidth: 0.005,
  lineBright: 1.5,
  minLineWidth: 2,
  maxLineWidth: 10,
  withArrow: true
}
