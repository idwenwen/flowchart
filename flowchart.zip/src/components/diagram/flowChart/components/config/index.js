export const config = {
  panelBorder: 0.1,

  // component text
  maxWidth: 0.9,
  maxHeight: 0.9,

  fontSize: 0.85,
  fontStyle: 'normal',
  fontFamily: 'arial'
}
