export const config = {
  panelBorder: 0.05
}
